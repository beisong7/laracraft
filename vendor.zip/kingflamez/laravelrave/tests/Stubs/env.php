<?php

/**
 * Stub required environment variables.
 *
 * @return array
 */
return [
    "prefix" => "rave",
    "secretKey" => "FLWSECK-4127f15e63c9098402dcc7891798fb0f-X",
    "publicKey" => "FLWPUBK-1cf610974690c2560cb4c36f4921244a-X",
    "title" => "Rave Payment Gateway",
    "env" => "testing",
    "logo" => "https://files.readme.io/ee907a0-small-rave_by_flutterwave.png"
];
